import streamlit as st
import pandas as pd
import plotly.express as px
st.header("AI Transformation and Workforce Impact")
df=pd.read_csv("techlayoffs.csv")
st.dataframe(df)
c1,c2,c3,c4,c5=st.columns(5)
with c1: 
    st.metric("Average Ai adoption level",df["ai_adoption_level"].mean())
with c2:
    st.metric("Average Ai replacement risk",df["ai_replacement_risk"].mean())
with c3:
    st.metric("Average automation impact",df["ai_automation_impact"].mean())
with c4:
    st.metric("Average remote work",df["remote_jobs_percentage"].mean())
c5,c6=st.columns(2)
with c5:
    st.metric("Average job security score",df["job_security_score"].mean())


ai_distributin=df.groupby("ai_adoption_level").value_counts().reset_index()
fig1=px.histogram(data_frame=df,x="ai_adoption_level",color="ai_adoption_level")
st.plotly_chart(fig1)
replace_distributin=df.groupby("ai_replacement_risk").value_counts().reset_index()
fig2= px.line(data_frame=df,x="ai_replacement_risk",color="ai_replacement_risk")
st.plotly_chart(fig2)
industry_distributin=df.groupby("ai_automation_impact").value_counts().reset_index()
fig3 = px.histogram(data_frame= df , x = "ai_automation_impact" ,  color= "ai_automation_impact")
st.plotly_chart(fig3)
company_distributin=df.groupby("ai_adoption_level")["layoffs_count"].value_counts()
fig4=px.density_heatmap(data_frame=df,x="ai_adoption_level", y="layoffs_count")
st.plotly_chart(fig4)
country_distributin=df.groupby("ai_replacement_risk")["open_roles"].value_counts()
fig5=px.scatter(data_frame=df,x="ai_replacement_risk",y="open_roles")
st.plotly_chart(fig5)

open_distributin=df.groupby("ai_adoption_level")["employee_sentiment"].value_counts()
fig6=px.line(data_frame=df,x="ai_adoption_level",y="employee_sentiment",color="ai_adoption_level")
st.plotly_chart(fig6)
country_distributin=df.groupby("industry")["ai_adoption_level"].value_counts()
fig7=px.box(data_frame=df,x="industry",y="ai_adoption_level",color="industry")
st.plotly_chart(fig7)
hiring_distributin=df.groupby("company_size")["ai_adoption_level"].value_counts()
fig8=px.violin(data_frame=df,x="company_size",y="ai_adoption_level",color="company_size")
st.plotly_chart(fig8)
# with st.sidebar:
#     st.multiselect("select country",df["country"].unique())
#     st.selectbox("select industry",df["industry"].unique())
#     st.radio("select company size",df["company_size"].unique())




