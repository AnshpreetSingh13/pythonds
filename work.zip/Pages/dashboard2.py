import streamlit as st
import pandas as pd
import plotly.express as px
st.header("Layoff and Hiring Analytics")
df=pd.read_csv("techlayoffs.csv")
st.dataframe(df)
c1,c2,c3,c4,c5=st.columns(5)
with c1: 
    st.metric("Total Layoffs",df["layoffs_count"].sum())
with c2:
    st.metric("Average Layoffs Percentage",df["layoff_percentage"].mean())
with c3:
    st.metric("Highest Layoffs",df["layoffs_count"].max())
with c4:
    st.metric("Average Open Roles",df["open_roles"].mean())
c5,c6=st.columns(2)
with c5:
    st.metric("Hiring Growth Index",df["hiring_trend"].nunique())


layoff_distributin=df.groupby("layoffs_count").value_counts()
fig1=px.scatter(data_frame=df,x="layoffs_count",color="layoffs_count")
st.plotly_chart(fig1)
layoffs_distributin=df.groupby("layoff_percentage").value_counts()
fig2= px.imshow(df.corr(numeric_only= True))
st.plotly_chart(fig2)
industry_distributin=df.groupby("industry")["layoff_percentage"].value_counts()
fig3 = px.box(data_frame= df , x = "industry" , y = "layoff_percentage" , color= "industry")
st.plotly_chart(fig3)
company_distributin=df.groupby("company_size")["layoff_percentage"].value_counts()
fig4=px.violin(data_frame=df,x="company_size", y="layoff_percentage",color="company_size")
st.plotly_chart(fig4)
country_distributin=df.groupby("country")["layoff_percentage"].sum().reset_index()
fig5=px.pie(data_frame=df,names="country",values="layoff_percentage",hole=0.5)
st.plotly_chart(fig5)

open_distributin=df.groupby("layoffs_count")["open_roles"].value_counts()
fig6=px.histogram(data_frame=df,x="layoffs_count",y="open_roles",nbins=10)
st.plotly_chart(fig6)
country_distributin=df.groupby("reason_for_layoffs").sum().reset_index().nlargest(5,["layoffs_count"])
fig7=px.histogram(data_frame=df,x="reason_for_layoffs",color="reason_for_layoffs")
st.plotly_chart(fig7)
hiring_distributin=df.groupby("hiring_trend")["open_roles"].value_counts()
fig8=px.bar(data_frame=df,x="hiring_trend",y="open_roles",color="hiring_trend")
st.plotly_chart(fig8)
# with st.sidebar:
#     st.multiselect("select country",df["country"].unique())
#     st.selectbox("select industry",df["industry"].unique())
#     st.radio("select company size",df["company_size"].unique())




