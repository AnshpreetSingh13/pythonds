import streamlit as st
import pandas as pd
import plotly.express as px
st.title("Project on Techlayoffs")
st.header("Executive Workforce Overview")
df=pd.read_csv("techlayoffs.csv")
st.dataframe(df)
c1,c2,c3,c4=st.columns(4)
with c1: 
    st.metric("Total Companies",df["company_name"].nunique())
with c2:
    st.metric("Total Layoffs",df["layoffs_count"].sum())
with c3:
    st.metric("Total Open Roles",df["open_roles"].sum())
with c4:
    st.metric("Average AI Adoption Level",df["ai_adoption_level"].mean())
c5,c6,c7,c8=st.columns(4)
with c5:
    st.metric("Average Revenue Growth",df["revenue_growth_percent"].mean())
with c6:
    st.metric("Average Stock Growth",df["stock_growth_percent"].mean())
with c7:
    st.metric("Average Employee Sentiment",df["employee_sentiment"].mean())
with c8:
    st.metric("Average Job Security Score",df["job_security_score"].mean())
industry_distributin=df.groupby("industry").value_counts()
fig1=px.histogram(data_frame=df,x="industry",color="industry")
st.plotly_chart(fig1)
country_distributin=df.groupby("country").value_counts()
fig2=px.treemap(data_frame=df,path=["country"],color="country")
st.plotly_chart(fig2)
company_distributin=df.groupby("company_size").value_counts()
fig3=px.pie(data_frame=df,names="company_size",hole=0.5)
st.plotly_chart(fig3)
Hiring_distributin=df.groupby("hiring_trend").value_counts()
fig4=px.bar(data_frame=df,x="hiring_trend",color="hiring_trend")
st.plotly_chart(fig4)
Market_distributin=df.groupby("market_condition")["job_security_score"].sum().reset_index()
fig5=px.pie(data_frame=df,names="market_condition",values="job_security_score")
st.plotly_chart(fig5)
industry_distributin=df.groupby("industry")["layoffs_count"].sum().reset_index()
fig6=px.box(data_frame=df,x="industry",y="layoffs_count",color="industry")
st.plotly_chart(fig6)
country_distributin=df.groupby("country")["open_roles"].sum().reset_index()
fig7=px.violin(data_frame=df,x="country",y="open_roles",color="country")
st.plotly_chart(fig7)
# with st.sidebar:
#     st.multiselect("select country",df["country"].unique())
#     st.selectbox("select industry",df["industry"].unique())
#     st.radio("select company size",df["company_size"].unique())




